﻿namespace BikeTouringGISLibrary.Enumerations
{
    public enum ZoomOption
    {
        Unknown,
        ZoomIn,
        ZoomOut
    }
}