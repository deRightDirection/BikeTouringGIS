﻿namespace BikeTouringGISLibrary.Enumerations
{
    public enum ExtentChangedReason
    {
        Unknown,
        CenterMap,
        CenterLayer,
        ZoomIn,
        ZoomOut,
        Pan,
        StatusBarZoomInOrZoomOut
    }
}