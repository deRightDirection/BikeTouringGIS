﻿namespace BikeTouringGISLibrary.Enumerations
{
    public enum LayerType
    {
        Unknown,
        PointsOfInterest,
        GPXRoute,
        SplitRoutes
    }
}