﻿using System.Windows.Controls;

namespace BikeTouringGIS.Controls
{
    /// <summary>
    /// Interaction logic for NewProjectDialog.xaml
    /// </summary>
    public partial class NewProjectDialog : UserControl
    {
        public NewProjectDialog()
        {
            InitializeComponent();
        }
    }
}