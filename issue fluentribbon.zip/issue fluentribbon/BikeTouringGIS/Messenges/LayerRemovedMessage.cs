﻿using BikeTouringGIS.Controls;

namespace BikeTouringGIS.Messenges
{
    internal class LayerRemovedMessage
    {
        public BikeTouringGISLayer Layer { get; set; }
    }
}