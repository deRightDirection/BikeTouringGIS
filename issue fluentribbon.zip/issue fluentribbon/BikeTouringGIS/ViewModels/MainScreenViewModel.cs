﻿using GalaSoft.MvvmLight;

namespace BikeTouringGIS.ViewModels
{
    public class MainScreenViewModel : ViewModelBase
    {
        /*
        // TODO: nog niet volledig mvvm
        private async void AddPOI()
        {
            await _dialogCoordinator.ShowInputAsync(this, "Name of POI", "Fill in the name of POI and click ok.")
                .ContinueWith(t => _poiName = t.Result);
            if(string.IsNullOrEmpty(_poiName))
            {
                await _dialogCoordinator.ShowMessageAsync(this, "Name of POI", "No name for POI given");
            }
            else
            {
                await _dialogCoordinator.ShowMessageAsync(this, "Name of POI", "After closing this window double click on the map for the location of the POI");
                _poiClickMode = true;
            }
        }
        */
    }
}